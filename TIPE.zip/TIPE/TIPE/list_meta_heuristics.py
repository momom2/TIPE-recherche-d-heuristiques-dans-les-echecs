#Ce fichier liste des metaheuristiques.
#Il se réfère à list_heuristics et len_db.



import random
def random_or(n):
    list_random_heuristics = [list_heuristics[random.randrange(len(list_heuristics))] for _ in range(n)]
    def lambda(position):
        for i in range(n):
            if list_random_heuristics[i][0](position) == True:
                return True
        return False
    return (lambda,
        
