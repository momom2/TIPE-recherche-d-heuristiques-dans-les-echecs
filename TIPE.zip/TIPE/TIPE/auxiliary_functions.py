


def average(liste):
    return sum(liste)/len(liste)



    
def split(l):
    middle = int(len(l)/2)
    return l[:middle],l[middle:]

def function_merge_sort_by(evaluate):
    def merge(l1,l2):
        if l1 ==[]:
            return l2
        elif l2 == []:
            return l1
        else:
            if evaluate(l1[0])>evaluate(l2[0]):
                return [l1[0]]+merge(l1[1:],l2)
            else:
                return [l2[0]]+merge(l1,l2[1:])

    def merge_sort(l):
        if l == [] or l == [l[0]]:
            return l
        else:
            spl0,spl1 = split(l)
            return merge(merge_sort(spl0),merge_sort(spl1))

    return merge_sort

