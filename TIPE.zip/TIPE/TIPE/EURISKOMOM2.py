#import extract_bdd


from auxiliary_functions import *
#sort_by_worth = function_merge_sort_by(1)


#heuristic = [boolean function evaluating a position
#    ,worth, [example], [generalization], [specialization],[border_case]]


import list_heuristics as lh
#the end goal of the script is to expand the list of interesting heuristics
#sorted by decreasing score






def add_heuristics(list_new_heuristics):
    for new_heuristic in list_new_heuristics:
        insert_by_worth(new_heuristic)

from numpy import random as rd
def random_heuristic(list_sorted,n):
    i = round(rd.exponential(n))
    if i >= len(list_sorted):
        return random_heuristic(list_sorted,n)
    else:
        return list_sorted[i]

random_heuristic(list_sorted,400)
def create_OR_heuristic(list_sorted):
    h1,h2 = rd.exponential(list_sorted,len(list_sorted)/2),rd.exponential(list_sorted,len(list_sorted)/2)
    def assertion(position):
        return (h1[0](position) or h2[0](position))
    return (assertion,lh.score(assertion))
def create_AND_heuristic(list_sorted):
    h1,h2 = rd.exponential(list_sorted,len(list_sorted)/2),rd.exponential(list_sorted,len(list_sorted)/2)
    def assertion(position):
        return (h1[0](position) and h2[0](position))
    return (assertion,lh.score(assertion))
#def mutate(heuristic):
#    list_new_heuristics = []
#    for metaheuristic in list_metaheuristics:
#        if metaheuristic[0](heuristic):
#            list_new_heuristics.append(metaheuristic[1](heuristic))
#    add_heuristics(list_new_heuristics)

#metaheuristic = (#function that searches for heuristics worth mutating
#    , #function that mutates one or multiple heuristics and updates its facets
#    )



    


