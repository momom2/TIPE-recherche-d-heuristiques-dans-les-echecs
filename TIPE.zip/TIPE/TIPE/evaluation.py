#database = [(liste_positions,
#    couleur_gagnante#B, N ou G (pour égalité)
#    )]


#position = ([cases
#    ],
#    tour,
#    couleur_qui_a_le_trait,
#    en_échec,
#    case_en_passant#(-1,-1) si pas
#    )



def evaluation_atemporelle(position):
    favorable_trait = 0
    favorable_adverse = 0
    nulle = 0
    positions_pertinentes = 0
    liste_cases,_,couleur,_,_ = position
    for liste_positions,gagnant in database:
        for echiquier,_,c,_,_,_ in liste_positions:
            if l_c,c = list_cases,couleur:
                if gagnant == couleur:
                    favorable_trait += 1
                elif gagnant == "G":
                    nulle += 1
                else:
                    favorable_adverse += 1
                positions_pertinentes += 1
    proportion_trait =  favorable_trait/positions_pertinentes
    proportion_adverse = favorable_adverse/positions_pertinentes
    proportion_nulle = nulle/positions_pertinentes
    return proportion_trait,proportion_adverse,proportion_nulle,positions_pertinentes


